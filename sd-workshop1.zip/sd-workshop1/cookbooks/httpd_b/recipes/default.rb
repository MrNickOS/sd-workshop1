include_recipe 'httpd_b::httpd_install'
include_recipe 'httpd_b::httpd_config'
include_recipe 'httpd_b::httpd_copy_files'
