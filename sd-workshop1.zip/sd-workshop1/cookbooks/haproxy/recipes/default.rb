include_recipe "haproxy::haproxy_install"
include_recipe "haproxy::haproxy_config"
