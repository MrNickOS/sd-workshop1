include_recipe 'nginx::nginx_install'
include_recipe 'nginx::nginx_config'
