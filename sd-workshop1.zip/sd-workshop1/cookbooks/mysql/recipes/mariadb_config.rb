cookbook_file '/etc/yum.repos.d/MariaDB.repo' do
	source 'MariaDB.repo'
	mode 0644
	owner 'root'
	group 'wheel'
end

cookbook_file '/tmp/create_schema.sql' do
	source 'create_schema.sql'
	mode 0644
	owner 'root'
	group 'wheel'
end

#bash 'create schema' do
#	user 'root'
#	cwd '/tmp'
#	code <<-EOH
#	cat create_schema.sql | mysql -u root -ppassword
#	EOH
#end

service 'mariadb.service' do
	action [:start, :enable]
end
