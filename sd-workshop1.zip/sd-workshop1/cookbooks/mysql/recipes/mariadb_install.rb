yum_package 'mariadb-server'
