<?php
 $con = mysql_connect("192.168.60.100","usuario1","database2017");
 if (!$con)
   {
   die('Could not connect: ' . mysql_error());
   }

 mysql_select_db("base_datos_1", $con);

 $result = mysql_query("SELECT * FROM cursos");

 while($row = mysql_fetch_array($result))
   {
   echo $row['nombre'] . " " . $row['horas_semana'] . " " . $row['salon'];
   echo "<br />";
   }

 mysql_close($con);
?>
