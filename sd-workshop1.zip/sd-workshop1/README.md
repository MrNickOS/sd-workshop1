### Taller 1 Sistemas Distribuidos
**Tema:** Automatización de Infraestructura
**Presentado por:** Nicolás Machado Sáenz

En esta actividad, se realiza la automatización de una pequeña infraestructura virtual que consta
de un equipo físico y 4 máquinas montadas en el hyper-V Virtualbox:
* Un balanceador de carga utilizando la herramienta NGINX.
* Dos servidores web Apache, que se encargan de recibir peticiones.
* Un servidor de base de datos Maria-DB.
* El equipo físico es un cliente Ubuntu 16.04.

El primer paso es verificar que se cuenta con la estructura de carpetas dentro de la carpeta base
de trabajo. Para esto se debe usar el comando tree, que muestra el árbol de carpetas y archivos en
el folder de trabajo.

"Figura 1: Tree"

Los cookbooks incluyen archivos en lenguaje ruby que administran cada máquina a crear acorde a la
disposición del Vagrantfile. En las recetas terminadas en **install** existen líneas que realizan la
instalacion del software asociado a 
